import 'package:flutter/material.dart';
import 'package:final_mealsrecipe/app_config.dart';
import 'package:final_mealsrecipe/main_common.dart';

void main() {
  var configuredApp = AppConfig(
    appDisplayName: "App 1",
    appInternalId: 1,
    child: MyApp(),
  );

  mainCommon();
  runApp(configuredApp);
}