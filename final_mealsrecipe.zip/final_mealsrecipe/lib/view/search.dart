import 'dart:async';
import 'package:final_mealsrecipe/view/detail.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:final_mealsrecipe/model/ingredients.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  List<Ingredients> ingredients = [];
  String txtSearch;
  Timer timeHandle;
  bool notValue;

  void textChanged(String txt) {
    txtSearch = txt;
    if (timeHandle != null) {
      timeHandle.cancel();
    }
    timeHandle = Timer(Duration(seconds: 0), () async {
      String dataURL =
          "https://www.themealdb.com/api/json/v1/1/search.php?s=$txtSearch";
      http.Response response = await http.get(dataURL);
      var responseJson = json.decode(response.body);
      if (response.statusCode == 200 && responseJson['meals'] != null) {
        ingredients = (responseJson['meals'] as List)
            .map((p) => Ingredients.fromJson(p))
            .toList();
        notValue = false;
      } else {
        notValue = true;
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    timeHandle.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          key: Key('text_search'),
            onChanged: textChanged,
            style: TextStyle(color: Colors.white),
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: 'Type a keyword',
            )),
          leading: IconButton(
            key: Key('back_fromsearch'),
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context, false),
          ),
        backgroundColor: Colors.lightGreen,
      ),
      body: getBodySearch(),
    );
  }

  getBodySearch() {
    if (ingredients.length == 0) {
      return Center(child: Text('Search Meals', key: Key('search_meals'),));
    } else {
      if (notValue == true) {
        return Center(child: Text('data not found', key: Key('notfound'),));
      } else {
        return getListSearch();
      }
    }
  }

  ListView getListSearch() => ListView.builder(
        itemCount: ingredients.length,
        itemBuilder: (BuildContext context, int position) {
          return getSearch(position);
        },
      );

  Widget getSearch(int i) {
    return GestureDetector(
      child: Container(
          child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Image.network(ingredients[i].strMealThumb,
                  height: 50.0, width: 50.0, key: Key('list_search'),),
              Padding(
                padding: EdgeInsets.all(4.0),
              ),
              Text(ingredients[i].strMeal)
            ],
          )
        ],
      )),
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    IngredientsDetailPage(ingredients: ingredients[i])));
      },
    );
  }
}