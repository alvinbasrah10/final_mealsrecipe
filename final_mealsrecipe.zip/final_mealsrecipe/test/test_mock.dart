import 'dart:convert';

import 'package:final_mealsrecipe/model/ingredients.dart';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
  
import 'package:mockito/mockito.dart';

class MockClient extends Mock implements http.Client {}

void main() {

  group('loadData', () {
    test('Menampilkan sebuah post jika data berhasil diambil', () async {
      final client = MockClient();

      //gunakan mockito
      when(client.get(
              'https://www.themealdb.com/api/json/v1/1/filter.php?c=Desert'))
          .thenAnswer((_) async => http.Response(
              '{"meals" : ["strMeal" : "Apple & Blackberry Crumble"]}', 200));

      expect(await loadData(), isInstanceOf<Ingredients>());
    });
  });
}

loadData() async {
  String dataURL =
      "https://www.themealdb.com/api/json/v1/1/filter.php?c=Desert";
  http.Response response = await http.get(dataURL);
  var responseJson = json.decode(response.body);
  if (response.statusCode == 200) {
    var ingredients = (responseJson['meals'] as List)
        .map((p) => Ingredients.fromJson(p))
        .toList();
        print(ingredients);
  } else {
    throw Exception('Failed to load photos');
  }
}
