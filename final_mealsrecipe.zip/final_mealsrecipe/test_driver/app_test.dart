// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility that Flutter provides. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:test/test.dart';
import 'package:flutter_driver/flutter_driver.dart';

void main() {
  group(('Skenario Test'), (){
    //deklarasi semua key
    final navbarDesert = find.byValueKey('choose_desert');
    final appbarDesert = find.byValueKey('desert_list');
    final appbarSeafood = find.byValueKey('seafood_list');
    final iconSea = find.byValueKey('icon_sea');
    final gridSeafood = find.byValueKey('gridview_seafood');
    final detailPage = find.byValueKey('detail_page');
    final favorited = find.byValueKey('favorited');
    final responseFav = find.byValueKey('response_fav');
    final backBtn = find.byValueKey('kembali');
    final iconFav = find.byValueKey('icon_fav');
    final appbarFav = find.byValueKey('favorite_page');
    final iconSeaFav = find.byValueKey('icon_seafood');
    final gridFav = find.byValueKey('gridfav_seafood');
    final appbardetailFav = find.byValueKey('appbardetail_fav');
    final btnDel = find.byValueKey('delete');
    final dialogDel = find.byValueKey('tombol_delete');
    final btnSearch = find.byValueKey('search_icon');
    final searchPage = find.byValueKey('search_meals');
    final btnbackSearch = find.byValueKey('back_fromsearch');

    FlutterDriver driver;

    //connect
    setUpAll(() async{
      driver = await FlutterDriver.connect();
    });

    //dissconnect
    tearDownAll(() async{
      if(driver != null){
        driver.close();
      }
    });

    //test section

    // skenario 1
    test('starts at 0', () async {
      
    expect(await driver.getText(navbarDesert), "Desert");
    expect(await driver.getText(appbarDesert), "Desert List");
    });

    //Skenario 2
    test('pilih navbaritem', () async{

      await driver.tap(iconSea);

      expect(await driver.getText(appbarSeafood), 'Seafood List');
    });

    //Skenario 3
    test('klik gridview', () async {

      await driver.tap(gridSeafood);

      expect(await driver.getText(detailPage), 'Detail Ingredients');

    });

    //skenario 4
    test('favorited', () async {

     await driver.tap(favorited);

     expect(await driver.getText(responseFav), 'Added to favorite'); 
    });

    // skenario 4.1
    test('kembali', () async {

      await driver.tap(backBtn);

      expect(await driver.getText(appbarSeafood), 'Seafood List');
      
    });

    //skenario 5
    test('search page', () async {
      await driver.tap(btnSearch);

      expect(await driver.getText(searchPage), 'Search Meals');
    });

    //skenario 5.1
    test('back from search', () async {
      await driver.tap(btnbackSearch);

      expect(await driver.getText(appbarSeafood), 'Seafood List');
    });

    //skenario 6
    test('favorite list page', () async {

      await driver.tap(iconFav);

      expect(await driver.getText(appbarFav), 'Favorite Page');
    });

    // skenario 7
    test('choose seafood fav page', () async {
      
      await driver.tap(iconSeaFav);

      expect(await driver.getText(appbarFav), 'Favorite Page');
    });

    //skenario 7.1
    test('klik grid favorite', () async {
      
      await driver.tap(gridFav);

      expect(await driver.getText(appbardetailFav), 'Detail Favorite Ingredients');

    });

    // skenario 8
    test('dialog delete favorite', () async {

      await driver.tap(btnDel);

      expect(await driver.getText(dialogDel), 'Delete');

    });

  });
}

//Skenario
/*
1. Aplikasi dibuka, navigation bar yang aktif 0, yaitu desert, dan nampilin gridview desert dan appbar desert
2. jika dipilih tiap navigation bar muncul gridview terkait dan appbar terkait
3. jika klik gridview, beralih ke detail page dan menampilkan detail masakan dan appbar detail ingredients
4. di detail page jika ingin menambah resep ke favorit, klik tombol love, jika sudah, love berubah warna merah dan action jadi null, user mengklik tombol kembali
5. jika klik tombol search, beralih ke halaman khusus search, dan ketika belum memasukan apa-apa, muncul text search meals dan user klik tombol kembali. 
6. jika tabbar seafood pada navbar favorit di klik, dan menampilkan gridview seafood
7. jika navbar favorite di klik, muncul halaman yang memiliki appbar favorite page dan mengarah ke tabbar awal yaitu desert favorit dan menampilkan gridview desert
8. jika gridview di klik, muncul halaman yang memiliki appbar detail ingredient favorite dan ada tombol love yang sudah berwarna merah yang mana ketika di klik terdapat dialog box delete data.
*/